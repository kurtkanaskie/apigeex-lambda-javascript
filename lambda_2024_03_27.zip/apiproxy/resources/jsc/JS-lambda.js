/* globals print */
/* globals context */
/* jslint latedef:false */
// Adapted from: https://github.com/aws/aws-sdk-js/blob/master/lib/signers/v4.js

// Get KVM values
const lambda_key = context.getVariable('lambda_key');
const lambda_region = context.getVariable('lambda_region');
const lambda_service = context.getVariable('lambda_service');
// const lambda_host = context.getVariable('lambda_host');

// Get other values
const algorithm = context.getVariable('algorithm');
const requestType = context.getVariable('requestType');
const amzDate = context.getVariable('amzDate');
const amzDatetime = context.getVariable('amzDatetime');
const method = context.getVariable('request.verb');
const path = context.getVariable('proxy.pathsuffix');
const body = context.getVariable('request.content');

// Create array, convert to lowercase and sort
const hs = String(context.getVariable('request.headers.names'));
const headersArray = hs.substring(1, hs.length - 1).split(new RegExp(', ', 'g'));
var headersSorted = [];
headersArray.forEach(function(header) {
    headersSorted.push(header.toLowerCase());
});
headersSorted.sort();

// Calculated values
function stringToSign() {
  var parts = [];
  parts.push(algorithm);
  parts.push(amzDatetime);
  parts.push(credentialString());
  parts.push(hexEncodedHash(canonicalString()));
  return parts.join('\n');
}

function canonicalQueryParams() {
    return '';
}

// https://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html
function canonicalString() {
  var parts = [];
  parts.push(method);
  parts.push(path);                         // this is e.g. "/pathsuffix/resource"
  parts.push(canonicalQueryParams());       // not supported here
  parts.push(canonicalHeaders() + '\n');    // need empty line after headers
  parts.push(signedHeaders());
  parts.push(hexEncodedBodyHash());
  return parts.join('\n');
}

// Needs to check for empty or invalid values
function canonicalHeaders() {
  var parts = [];
  headersSorted.forEach(function(header) {
    if (isSignableHeader(header)) {
      value = context.getVariable('request.header.' + header);
      parts.push(header.toLowerCase() + ':' + canonicalHeaderValues(value.toString())); 
    } 
  });
  return parts.join('\n');
}

function canonicalHeaderValues(values) {
  return values.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
}

function signedHeaders() {
  var parts = [];
  headersSorted.forEach(function(header) {
    if (isSignableHeader(header)) {
        parts.push(header);
    }
  });
  return parts.join(';');
}

function credentialString() {
  return [amzDate,lambda_region,lambda_service,requestType].join('/');
}

function hexEncodedHash(string) {
    var _sha256 = crypto.getSHA256();
    _sha256.update(string);
    var _hashed_token = _sha256.digest();
    return _hashed_token;
}

// not supported here - only for gets for now
function hexEncodedBodyHash() {
  return hexEncodedHash('');
}

unsignableHeaders = [
    'authorization',
    'content-type',
    'content-length',
    'user-agent',
    'expect',
    'x-amzn-trace-id'
];

function isSignableHeader(key) {
if (key.toLowerCase().indexOf('x-amz-') === 0) return true;
    return unsignableHeaders.indexOf(key) < 0;
}

context.setVariable("canonicalHeaders", canonicalHeaders());
context.setVariable("canonicalString", canonicalString());
context.setVariable("credentialString", credentialString());
context.setVariable("signedHeaders", signedHeaders());
context.setVariable("stringToSign", stringToSign());
